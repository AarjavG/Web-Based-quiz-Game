Quiz Game
======================

This is a simple Quiz game using html, css, jquery, and nodejs.

Steps
=================

|___ 1. Extract all files to your web root.
|
|___ 2. Run the 'index.cjs' file in the terminal to get the questions from the server using api
|
|___ 3. Run the 'homepage.html' file to redirect to the game on the port 5500.

